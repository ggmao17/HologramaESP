package com.example.hologramaesp

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Bg = Color(0xFF08090D)
private val Panel = Color(0xFF171A22)
private val Neon = Color(0xFFFF2448)
private val Cyan = Color(0xFF37E7FF)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { HologramaScreen() }
    }
}

@Composable
fun HologramaScreen() {
    var esp by remember { mutableStateOf(true) }
    var boxes by remember { mutableStateOf(true) }
    var labels by remember { mutableStateOf(true) }
    var distance by remember { mutableStateOf(true) }

    MaterialTheme {
        Column(
            Modifier.fillMaxSize().background(Bg).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text("HOLOGRAMA ESP", color = Neon, fontSize = 27.sp, fontWeight = FontWeight.Black)
            Text("SIMULADOR VISUAL • ALVOS FICTÍCIOS", color = Color.LightGray, fontSize = 11.sp)

            Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
                Column(Modifier.padding(12.dp)) {
                    Text("PRÉVIA DO HOLOGRAMA", color = Cyan, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    Canvas(Modifier.fillMaxWidth().height(270.dp).background(Color(0xFF0D1820), RoundedCornerShape(12.dp))) {
                        // Grid de fundo para dar aparência de visor holográfico
                        for (i in 0..10) {
                            val x = size.width * i / 10f
                            drawLine(Cyan.copy(alpha = 0.12f), Offset(x, 0f), Offset(x, size.height), 1f)
                        }
                        for (i in 0..8) {
                            val y = size.height * i / 8f
                            drawLine(Cyan.copy(alpha = 0.12f), Offset(0f, y), Offset(size.width, y), 1f)
                        }
                        if (esp) {
                            val centers = listOf(
                                Offset(size.width * .25f, size.height * .52f),
                                Offset(size.width * .52f, size.height * .42f),
                                Offset(size.width * .77f, size.height * .58f)
                            )
                            centers.forEachIndexed { index, p ->
                                val w = 54f
                                val h = 112f
                                if (boxes) {
                                    drawRect(Neon, Offset(p.x-w/2, p.y-h/2), androidx.compose.ui.geometry.Size(w,h), style = androidx.compose.ui.graphics.drawscope.Stroke(3f))
                                }
                                drawCircle(Cyan, 5f, Offset(p.x, p.y-h/2-13f))
                                drawLine(Cyan, Offset(p.x, p.y-h/2-8f), Offset(p.x, p.y-h/2+8f), 2f, cap = StrokeCap.Round)
                            }
                        }
                    }
                    Spacer(Modifier.height(6.dp))
                    Text(if (esp) "3 alvos de demonstração" else "ESP desligado", color = Color.White, fontSize = 12.sp)
                }
            }

            Text("CONTROLES", color = Neon, fontWeight = FontWeight.Bold, fontSize = 17.sp)
            ToggleRow("ESP de demonstração", esp) { esp = it }
            ToggleRow("Caixas de destaque", boxes) { boxes = it }
            ToggleRow("Nome dos alvos (visual)", labels) { labels = it }
            ToggleRow("Distância fictícia", distance) { distance = it }

            if (esp && (labels || distance)) {
                Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("ALVOS SIMULADOS", color = Cyan, fontWeight = FontWeight.Bold)
                        listOf("ALVO 01", "ALVO 02", "ALVO 03").forEachIndexed { i, name ->
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text(if (labels) name else "Alvo", color = Color.White)
                                if (distance) Text(listOf("18 m", "42 m", "67 m")[i], color = Cyan)
                            }
                        }
                    }
                }
            }
            Spacer(Modifier.weight(1f))
            Text("Este app é apenas uma simulação independente. Não se conecta ao Free Fire nem detecta jogadores reais.",
                color = Color.Gray, fontSize = 10.sp)
        }
    }
}

@Composable
fun ToggleRow(title: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(12.dp)).padding(horizontal = 12.dp, vertical = 5.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(title, color = Color.White, modifier = Modifier.weight(1f), fontSize = 14.sp)
        Switch(checked = checked, onCheckedChange = onChange,
            colors = SwitchDefaults.colors(checkedThumbColor = Color.White, checkedTrackColor = Neon))
    }
}
